var integer = parseInt(prompt("vnesi prv broj"), "0");
switch (integer) {
    case 1:{
        console.log("denot e ponedelnik");
        
    }
    case 2:{
        console.log("denot e vtornik");
        break;
    }
    case 3:{
        console.log("denot e sreda");
        break;
        }
    case 4:{
        console.log("denot e cetvrtok");
        break;
    }
    case 5:{
        console.log("denot e petok");
        break;
    }
    case 6:{
        console.log("denot e sabota");
        break;
    }
    case 7:{
        console.log("denot e nedela");
        break;
    }
    default:{
        console.log("vaj broj nije dn");
    }
}