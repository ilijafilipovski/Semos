var text = "Zdravo na site, long time no see"

console.log(text);
console.error(text)
console.warn(text)

var broj1 = 10;
var broj2 = 3;
var rezultat= broj1 / broj2;


